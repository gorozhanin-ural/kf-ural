# IT Website

## Описание

Учебный проект

## Используемые технологии

- HTML
- CSS
- БЭМ
- PerfectPixel
- Swiper.js

---

[Demo](https://it-website.nothingisreal.ru/)
